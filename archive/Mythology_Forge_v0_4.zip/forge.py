import json
from pathlib import Path

INPUT = Path("input/episode_bundle")
OUTPUT = Path("output/media_bundle")
SCENE_FRAMES = OUTPUT / "scene_frames"
TEASER_CLIPS = OUTPUT / "teaser_clips"

OUTPUT.mkdir(parents=True, exist_ok=True)
SCENE_FRAMES.mkdir(parents=True, exist_ok=True)
TEASER_CLIPS.mkdir(parents=True, exist_ok=True)

bundle = json.load(open(INPUT / "bundle.json"))
metadata = json.load(open(INPUT / "metadata.json")) if (INPUT / "metadata.json").exists() else {}
script_text = (INPUT / "script.txt").read_text(encoding="utf-8") if (INPUT / "script.txt").exists() else ""
scene_prompts = json.load(open(INPUT / "scene_prompts.json")) if (INPUT / "scene_prompts.json").exists() else []
episode_plan = json.load(open(INPUT / "episode_plan.json")) if (INPUT / "episode_plan.json").exists() else {}

episode_id = bundle.get("episode_id", "unknown_episode")
title = bundle.get("title", "Untitled Episode")
topic = bundle.get("topic", title)

(OUTPUT / "final_video.mp4").write_bytes(b"PLACEHOLDER_VIDEO_V0_4")
(OUTPUT / "thumbnail.png").write_bytes(b"PLACEHOLDER_THUMBNAIL_V0_4")

scene_asset_map = []
for i, scene in enumerate(scene_prompts, start=1):
    scene_id = scene.get("scene_id", f"scene_{i:02}")
    frame_name = f"{scene_id}.png"
    teaser_name = f"teaser_{i:02}_{scene_id}.mp4"

    (SCENE_FRAMES / frame_name).write_bytes(
        f"FRAME::{scene_id}::{scene.get('prompt','')}".encode()
    )
    (TEASER_CLIPS / teaser_name).write_bytes(
        f"TEASER::{scene_id}::{scene.get('narration','')}".encode()
    )

    scene_asset_map.append({
        "scene_id": scene_id,
        "frame": f"scene_frames/{frame_name}",
        "teaser_clip": f"teaser_clips/{teaser_name}",
        "prompt": scene.get("prompt", ""),
        "narration": scene.get("narration", "")
    })

if not scene_prompts:
    for i in range(1, 4):
        scene_id = f"scene_{i:02}"
        frame_name = f"{scene_id}.png"
        teaser_name = f"teaser_{i:02}_{scene_id}.mp4"
        (SCENE_FRAMES / frame_name).write_bytes(f"FRAME::{scene_id}".encode())
        (TEASER_CLIPS / teaser_name).write_bytes(f"TEASER::{scene_id}".encode())
        scene_asset_map.append({
            "scene_id": scene_id,
            "frame": f"scene_frames/{frame_name}",
            "teaser_clip": f"teaser_clips/{teaser_name}",
            "prompt": "",
            "narration": ""
        })

scene_asset_map_path = OUTPUT / "scene_asset_map.json"
json.dump(scene_asset_map, open(scene_asset_map_path, "w"), indent=2)

manifest = {
    "bundle_version": "1.0",
    "source_episode_id": episode_id,
    "generated_by": "Mythology Forge",
    "title": title,
    "topic": topic,
    "derived_from": {
        "bundle": "input/episode_bundle/bundle.json",
        "metadata": "input/episode_bundle/metadata.json",
        "script": "input/episode_bundle/script.txt",
        "scene_prompts": "input/episode_bundle/scene_prompts.json",
        "episode_plan": "input/episode_bundle/episode_plan.json"
    },
    "input_summary": {
        "series": metadata.get("series"),
        "tags": metadata.get("tags", []),
        "tone": metadata.get("tone"),
        "script_length_chars": len(script_text),
        "scene_prompt_count": len(scene_prompts),
        "target_duration_sec": episode_plan.get("target_duration_sec")
    },
    "scene_summary": scene_asset_map,
    "paths": {
        "final_video": "final_video.mp4",
        "thumbnail": "thumbnail.png",
        "scene_frames_dir": "scene_frames",
        "teaser_clips_dir": "teaser_clips",
        "scene_asset_map": "scene_asset_map.json"
    },
    "counts": {
        "scene_frames": len(list(SCENE_FRAMES.glob("*.png"))),
        "teaser_clips": len(list(TEASER_CLIPS.glob("*.mp4")))
    }
}
json.dump(manifest, open(OUTPUT / "media_manifest.json", "w"), indent=2)
print("media_bundle v0.4 created")
