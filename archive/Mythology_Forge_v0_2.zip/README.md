# Mythology Forge v0.2

Consumes `episode_bundle` and produces a richer `media_bundle`.

Run:
python forge.py
